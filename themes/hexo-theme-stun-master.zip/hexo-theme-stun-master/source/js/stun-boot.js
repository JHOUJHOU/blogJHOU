$(document).ready(function () {
  Stun.utils.showThemeInConsole();

  if (CONFIG.shortcuts && CONFIG.shortcuts.switch_post) {
    Stun.utils.registerHotkeyToSwitchPost();
  }

  // Not reload this, because it's changeless.
  if (CONFIG.external_link) {
    Stun.utils.addIconToExternalLink('#footer');
  }

  Stun.utils.pjaxReloadBoot = function () {
    if (CONFIG.codeblock) {
      var codeStyle = CONFIG.codeblock.style;

      if (codeStyle === 'default') {
        this.addCodeHeader();
        this.addCopyButton();
        this.registerCopyEvent();
      } else if (codeStyle === 'carbon') {
        this.addCodeHeader('carbon');
      }
    }
    if (CONFIG.reward) {
      this.registerShowReward();
    }
    if (CONFIG.lazyload) {
      this.lazyLoadImage();
    }
    if (CONFIG.gallery_waterfall) {
      this.showImageToWaterfall();
    }
    if (CONFIG.external_link) {
      var CONTAINER = '.archive, .post-header-title';
      this.addIconToExternalLink(CONTAINER);
    }
    if (CONFIG.fancybox) {
      this.wrapImageWithFancyBox();
    } else if (CONFIG.zoom_image) {
      this.registerClickToZoomImage();
    }
  };

  // Initializaiton
  Stun.utils.pjaxReloadBoot();
});
